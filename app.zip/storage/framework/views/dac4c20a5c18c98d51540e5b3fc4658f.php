<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soil Moisture | IoT</title>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            padding: 20px;
        }
        table tbody tr td {
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="my-4">Soil Monitor</h1>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Entry ID</th>
                    <th>Created At</th>
                    <th>Soil Monitor Voltage</th>
                    <th>Device Time</th>
                    <th>Wet Value</th>
                    <th>Manual Water Record</th>
                    <th>Dry Value</th>
                    <th>Email Flag</th>
                    <th>Office Temperature</th>
                    <th>Office Humidity</th>
                </tr>
            </thead>
            <tbody id="dataTable">
                <!-- Table rows will be dynamically added here -->
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
        function formatDate(dateString) {
            const options = { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
            return new Date(dateString).toLocaleDateString('en-US', options);
        }

        document.addEventListener('DOMContentLoaded', function() {
            const dataTable = document.getElementById('dataTable');

            const eventSource = new EventSource('/sse');

            eventSource.onmessage = function(event) {
                const data = JSON.parse(event.data);

                dataTable.innerHTML = `
                    <tr>
                        <td>${data.entry_id}</td>
                        <td>${formatDate(data.created_at)}</td>
                        <td>${data.field1 !== null ? data.field1 : 'N/A'}</td>
                        <td>${data.field2 !== null ? data.field2 : 'N/A'}</td>
                        <td>${data.field3 !== null ? data.field3 : 'N/A'}</td>
                        <td>${data.field4 !== null ? data.field4 : 'N/A'}</td>
                        <td>${data.field5 !== null ? data.field5 : 'N/A'}</td>
                        <td>${data.field6 !== null ? data.field6 : 'N/A'}</td>
                        <td>${data.field7 !== null ? data.field7 : 'N/A'}</td>
                        <td>${data.field8 !== null ? data.field8 : 'N/A'}</td>
                    </tr>
                `;
            };

            eventSource.onerror = function() {
                console.error('Error with the SSE connection.');
                eventSource.close();
            };
        });
    </script>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/small_projects/iot/resources/views/soil-moisture.blade.php ENDPATH**/ ?>